
	
		<div id="header">
			<h1>BIENVENIDA</h1>
		</div>

		<div id="content">
		 Bienvenido <?=$nombre ?> al sistema.
		</div>

			
	
