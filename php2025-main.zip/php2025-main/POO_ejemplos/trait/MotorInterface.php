<?php


interface MotorInterface
{
    function encender():bool;
    function apagar():bool;
    function estaEncendido():bool;
}

