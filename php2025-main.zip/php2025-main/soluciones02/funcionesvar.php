<?php
function calSuma($valor1, $valor2)
{
    $resultado = $valor1 + $valor2;
    return $resultado;
}

function calResta($valor1, $valor2)
{
    $resultado = $valor1 - $valor2;
    return $resultado;
}

function calMulti($valor1, $valor2)
{
    $resultado = $valor1 * $valor2;
    return $resultado;
}

function calDivi($valor1, $valor2)
{
    $resultado = $valor1 / $valor2;
    return $resultado;
}

function calModulo($valor1, $valor2)
{
    $resultado = $valor1 % $valor2;
    return $resultado;
}

function calPotencia($valor1, $valor2)
{
    
    $resultado = $valor1 ** $valor2;
    return $resultado;
}