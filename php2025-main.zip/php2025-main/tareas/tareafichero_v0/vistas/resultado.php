<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulario de Login</title>
     <link href="web/estilo.css" rel="stylesheet" type="text/css" />
</head>
<body>
<form>
   <p> Su contraseña se ha cambiado </p>
   <button type="button" onClick="window.location.href=''">
    Terminar
</button>

</form>    
</body>
</html>