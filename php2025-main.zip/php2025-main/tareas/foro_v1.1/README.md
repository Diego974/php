# Ejemplos de foro con tres ficheros index
---
1. index-basico.php  (Controlador sin control de sesiones)
2. index-sesion.php  (Controlador con control de sesiones)
3. index-sesion-csrf.php ( Controlador con control de sesiones y bloqueo de ataque CSRF)

Fichero: ataque.php - realica el ataque CSRF 
Para facilitar el ataque los formularios se envian por el método GET
---