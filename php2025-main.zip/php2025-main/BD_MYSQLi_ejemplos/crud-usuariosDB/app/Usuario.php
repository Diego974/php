<?php


class Usuario
{
    public $nombre;
    public $login;
    public $password;
    public $comentario;
    
}

